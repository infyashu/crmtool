export default interface coordinateDTO {
    lng: number;
    lat: number;
    name?: string;
}
export default function Loading(){
    return (
        <img alt="loading" src='https://media0.giphy.com/media/3oEjI6SIIHBdRxXI40/200.gif' />
    )
}
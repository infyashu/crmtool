import React from 'react';
const AlertContext = React.createContext(() => {});
export default AlertContext;